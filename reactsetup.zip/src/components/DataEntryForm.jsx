import React from 'react';
import { Formik, Form, Field, ErrorMessage, } from "formik";
import * as Yup from "yup";
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { useNavigate } from 'react-router-dom';

const LoginSchema = Yup.object().shape({
    firstName: Yup.string()
        .required("First Name is required"),
    lastName: Yup.string()
        .required("Last Name is required"),
    email: Yup.string()
        .email("Invalid email address format")
        .required("Email is required"),
});
const DataEntryForm = () => {
    let navigate = useNavigate();
    return (
        <>
            <div className="card container mt-5 mb-5" style={{ width: "45%" }}>
                <Formik
                    initialValues={{ firstName: '', lastName: '', email: "" }}
                    validationSchema={LoginSchema}
                    onSubmit={(values) => {
                        console.log(values);
                        toast.success("Data successfully!");
                        navigate("/");
                    }}
                >
                    {({ touched, errors, isSubmitting, values }) =>
                    (
                        <div className=''>
                            <div className="card-body row">
                                <div className="card-title col-lg-12 text-center">
                                    <h3 className="">Data Form</h3>
                                </div>
                            </div>
                            <Form>
                                <div className="form-group">
                                    <label htmlFor="firstName" className="">
                                        First Name
                                    </label>
                                    <Field
                                        type="text"
                                        name="firstName"
                                        placeholder="Enter First Name"
                                        className={`mt-2 form-control
                                        ${touched.firstName && errors.firstName
                                                ? "is-invalid"
                                                : ""
                                            }`}
                                    />
                                    <ErrorMessage
                                        component="div"
                                        name="firstName"
                                        className="invalid-feedback"
                                    />
                                </div>
                                <div className="form-group">
                                    <label htmlFor="lastName" className="mt-3">
                                        Last Name
                                    </label>
                                    <Field
                                        type="text"
                                        name="lastName"
                                        placeholder="Enter Last Name"
                                        className={`mt-2 form-control
                                        ${touched.lastName && errors.lastName
                                                ? "is-invalid"
                                                : ""
                                            }`}
                                    />
                                    <ErrorMessage
                                        component="div"
                                        name="lastName"
                                        className="invalid-feedback"
                                    />
                                </div>
                                <div className="form-group">
                                    <label htmlFor="email">Email</label>
                                    <Field
                                        type="email"
                                        name="email"
                                        placeholder="Enter email"
                                        autocomplete="off"
                                        className={`mt-2 form-control
                                        ${touched.email && errors.email ? "is-invalid" : ""}`}
                                    />
                                    <ErrorMessage
                                        component="div"
                                        name="email"
                                        className="invalid-feedback"
                                    />
                                </div>
                                <button
                                    type="submit"
                                    className="btn btn-primary btn-block m-4">
                                    Submit
                                </button>
                            </Form>
                        </div>
                    )
                    }
                </Formik>
                <ToastContainer />
            </div>
        </>
    )
}
export default DataEntryForm;