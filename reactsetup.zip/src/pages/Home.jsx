import React from 'react';

const Home = () => {
    return(
        <>
            <h1>this is a Home page</h1>
        </>
    )
}
export default Home;