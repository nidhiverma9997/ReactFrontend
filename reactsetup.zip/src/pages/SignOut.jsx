import React from 'react';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { useNavigate } from 'react-router-dom'

const SignOut = () => {
    let navigate = useNavigate();

    return(
        <>
            <ToastContainer />
        </>
    )
}
export default SignOut;