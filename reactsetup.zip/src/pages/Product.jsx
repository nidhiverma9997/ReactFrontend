import React from 'react';

const Product = () => {
    return(
        <>
            <h1>this is a Product page</h1>
        </>
    )
}
export default Product;